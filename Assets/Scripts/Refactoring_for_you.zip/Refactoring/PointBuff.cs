﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* This class is a buff that multiplies the points per second a player gets
 * by a set amount for a set duration. */
public class PointBuff : BuffPickup {
	private ScoreManager theScoreManager;						//need this as score manager controls the scoring
	public float buffAmount = 2f;								//how strong the strong the buff is (modifier)

	void Awake(){
		theScoreManager = FindObjectOfType<ScoreManager>();		//we need this so we can call the add points function within it
	}

	public override void ApplyBuff ()
	{
		theScoreManager.pointsPerSecond *= buffAmount;			//tell score manager to multiply the points per second by buffAmount
		theScoreManager.setBuff (_activeBuff, buffDuration);
	}

	public override void DisableBuff ()
	{
		base.DisableBuff ();
		theScoreManager.pointsPerSecond /= buffAmount;			//tell score manager to divide the points per second by theBuffAmount
		theScoreManager.hideBuff();
	}

}
