﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* This class is used as a base for any pickups that will have an effect that
 * lasts for a specific duration. It activates and disables itself */
public abstract class BuffPickup : Pickup {
	[Range(1,10)]public float buffDuration = 5f;			//how long buff will last for
	public static BuffPickup _activeBuff;			//used to avoid infinite loop and therefore stack overflow issue

	/*public static BuffPickup activeBuff { 			//checks if there is currently an existing active buff
		set { 
			if (_activeBuff != null) { 		//not null means a buff already exists
				_activeBuff.CancelBuff ();	//cancel it, which cancels the scheduled invokation
			}
			_activeBuff = value;				//set activeBuff to be whatever it is being set as 
		}
		get {
			return _activeBuff;
		}
	}*/


	public abstract void ApplyBuff ();				//what to do when active

	public virtual void DisableBuff (){		//what to revert back to when deactivated
		_activeBuff = null;					//this is the base functionality, which will be added onto in the subclasses (not overriden)
	}			

	public void CancelBuff(){				//this method is called when we need to cancel a buff earlier than the duration
		CancelInvoke ("DisableBuff");		//stops the scheduled disable call
		//Debug.Log("HEY! I've just Cancelled Invoke, and about to disable the buff myself");
		DisableBuff ();						//disables now instead
	}

	public override void OnPickup (Collider2D other)	//every buff will follow this pattern of activate and disable
	{
		//Debug.Log ("this is: " + this.ToString());
		//IS THERE ALREADY AN ACTIVE BUFF? meaning is Active buff not null?!
		//IF THERE AN ACTIVE BUFF (that is not null) CALL CANCEL BUFF ON THAT INSTANCE
		//SET ACTIVE BUFF TO BE THIS CURRENT BUFF INSTANCE

		if (_activeBuff != null) {
			_activeBuff.CancelBuff ();
		}
		_activeBuff = this;
		ApplyBuff ();
		Invoke ("DisableBuff", buffDuration);
	}
}

//wisdom
//can't override private methods
//shift and del makes a whole line disappeasr <3
//alt up/down switches lines <3