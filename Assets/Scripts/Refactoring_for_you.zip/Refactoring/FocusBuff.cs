﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* This pickup allows the player to focus without using any focus points*/
public class FocusBuff : BuffPickup {
	private PlayerController thePlayerController;					//need this as score manager controls the scoring
	private ScoreManager theScoreManager;

	void Awake(){
		thePlayerController = FindObjectOfType<PlayerController>();		//we need this so we can call the add points function within it
		theScoreManager = FindObjectOfType<ScoreManager>();	
	}

	public override void ApplyBuff ()
	{
		thePlayerController.freeFocus = true;			//tell the player controller it no longer needs to expend focus points
		theScoreManager.setBuff (_activeBuff, buffDuration);
	}

	public override void DisableBuff ()
	{	
		//Debug.Log ("I've hit disableBuff");
		base.DisableBuff ();							//ensures code from the base class in this method is executed
		thePlayerController.freeFocus = false;			//enable the expendeture of focus points in the player controller
		theScoreManager.hideBuff(); //test	
	}

}
